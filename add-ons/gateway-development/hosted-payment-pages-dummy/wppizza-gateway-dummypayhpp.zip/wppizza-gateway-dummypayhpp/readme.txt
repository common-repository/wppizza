=== WPPizza Gateway PayU Latam ===
Contributors: ollybach
Plugin URI: http://www.wp-pizza.com
Author URI: http://www.wp-pizza.com
Tags: PayU Latam, payulatam , gateway, wppizza
Requires at least: PHP 5.3+, WP 3.3 , WPPizza 3.0+, cUrl
Tested up to: 4.8
Stable tag: 1.0


WPPizza Gateway - PayU Latam Gateway for WPPizza - Requires Wordpress 4.0+, WPPIZZA 3.0+, PHP 5.3+, cUrl

== Description ==

WPPizza Gateway - PayU Latam Gateway for WPPizza - Enables PayU Latam Payments for orders using the Wordpress WPPIZZA Plugin - Requires Wordpress 4.0+, WPPIZZA 3.0+, PHP 5.3+, cUrl

== Changelog ==

1.0  
* Initial Release  
18th August 2017  

